from flask import Flask, render_template, request, jsonify
import numpy as np
import pandas as pd
import joblib

app = Flask(__name__)

# Load the trained KNN classification model
try:
    model = joblib.load('knn_classification_model.pkl')
except FileNotFoundError:
    print("Model file not found. Make sure the path is correct.")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get input values from the form
        open_close = float(request.form['openClose'])
        high_low = float(request.form['highLow'])

        # Make prediction
        prediction = model.predict(np.array([[open_close, high_low]]))

        # Interpret prediction
        prediction_text = "Stock price will increase. So you invest in it" if prediction[0] == 1 else "Stock price will decrease. Better to choose another"

        # Return prediction result to HTML page
        return render_template('index.html', prediction=prediction_text)
    except Exception as e:
        print("Error:", e)
        return render_template('index.html', prediction="Error occurred. Please check your input.")

if __name__ == '__main__':
    app.run()
